package com.mjwsolucoes.sistemanutricao.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@IdClass(Receita_Ingrediente_Id.class)
@NoArgsConstructor
@AllArgsConstructor
public class ReceitaIngrediente {
    @Id
    @Column(name = "receita_Id")
    private Long receitaId;

    @Id
    @Column(name = "ingrediente_id")
    private Long ingredienteId;

    private String medidaCaseira;
    private double pesoBruto;
    private double pesoLiquido;
    private double fatorCorrecao;
    private double custoCompra;
    private double custoUtilizado;
    private double custoTotal;
    private double custoPercapita;

    @ManyToOne
    @JoinColumn(name = "receita_id")
    private Receita receita;

    @ManyToOne
    @JoinColumn(name = "ingrediente_id")
    private Ingrediente ingrediente;

}