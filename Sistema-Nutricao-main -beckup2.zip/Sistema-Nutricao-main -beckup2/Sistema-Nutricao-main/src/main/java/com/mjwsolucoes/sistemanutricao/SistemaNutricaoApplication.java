package com.mjwsolucoes.sistemanutricao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaNutricaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SistemaNutricaoApplication.class, args);
    }

}
