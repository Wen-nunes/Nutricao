package com.mjwsolucoes.sistemanutricao.model;

public enum Role {
    ADMIN,
    USER,
    NUTRICIONISTA
}

