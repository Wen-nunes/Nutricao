package com.mjwsolucoes.sistemanutricao.model;
import java.io.Serializable;
import java.util.Objects;

public class Receita_Ingrediente_Id implements Serializable {
    private Long receitaId;
    private Long ingredienteId;

    public Receita_Ingrediente_Id() {}

    public Receita_Ingrediente_Id(Long receitaId, Long ingredienteId) {
        this.receitaId = receitaId;
        this.ingredienteId = ingredienteId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Receita_Ingrediente_Id that = (Receita_Ingrediente_Id) o;
        return receitaId == that.receitaId &&
                ingredienteId == that.ingredienteId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(receitaId, ingredienteId);
    }
}
