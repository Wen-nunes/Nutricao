package com.mjwsolucoes.sistemanutricao.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Receita {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    @Enumerated(EnumType.STRING)
    private CategoriaReceita categoria;
    private String modoPreparo;
    private int tempoPreparo;
    private int pesoPorcao;
    private int rendimento;
    private String Equipamentos;
    private int numeroPorcoes;
    private float fcc;
    private String medidaCaseira;

    @ManyToOne
    @JoinColumn(name = "nutricionista_id")
    private User nutricionista;

    @OneToOne(mappedBy = "receita", cascade = CascadeType.ALL)
    private PerfilNutricional perfilNutricional;

    @OneToMany(mappedBy = "receita", cascade = CascadeType.ALL)
    private List<ReceitaIngrediente> ingredientesAssociados = new ArrayList<>();

    // Getters e Setters
}